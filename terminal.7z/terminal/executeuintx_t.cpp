#include "executeuintx_t.h"

//*****************************************************
// this fucntion use to convert from uint8_t* to uint32_t*
//
// prama u32: is output value
//		 u8: input string
//
//*****************************************************

void u8_u32(uint32_t *u32, uint8_t *u8)
{
    u32[0] = (uint32_t)u8[3];
    u32[0] = (u32[0] << 8) | (uint32_t)u8[2];
    u32[0] = (u32[0] << 8) | (uint32_t)u8[1];
    u32[0] = (u32[0] << 8) | (uint32_t)u8[0];
};

//*****************************************************
// this fucntion use to convert from uint32_t* to uint8_t*
//
// prama u8: is output string
//		 u32: input string
//
//*****************************************************
void u32_u8(uint8_t *u8, uint32_t u32)
{
    u8[0] = u32;
    u8[1] = u32 >> 8;
    u8[2] = u32 >> 16;
    u8[3] = u32 >> 24;
    u8[4] = (uint8_t)'}';
};

void u8_u16(uint16_t *u16, uint8_t *u8)
{
    u16[0] = (uint32_t)u8[1];
    u16[0] = (u16[0] << 8) | (uint32_t)u8[0];
};

void u16_u8(uint8_t *u8, uint16_t u16)
{
    u8[0] = u16;
    u8[1] = u16 >> 8;
    u8[2] = (uint8_t)'}';
};

int find_len(uint8_t *kytu)
{
    int i = 0;
    while (kytu[i] != (uint8_t)'}')
    {
        i++;
    }
    return i + 1;
};
