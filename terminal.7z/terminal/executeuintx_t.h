#ifndef EXECUTEUINTX_T_H
#define EXECUTEUINTX_T_H


#include "stdio.h"
#include "string.h"
#include "cstdint"
#include "stdlib.h"

//*****************************************************
// this fucntion use to convert from uint8_t* to uint32_t*
//
// prama u32: is output value
//		 u8: input string
//
//*****************************************************

void u8_u32(uint32_t *u32, uint8_t *u8);
//*****************************************************
// this fucntion use to convert from uint32_t* to uint8_t*
//
// prama u8: is output string
//		 u32: input string
//
//*****************************************************
void u32_u8(uint8_t *u8, uint32_t u32);

void u8_u16(uint16_t *u16, uint8_t *u8);

void u16_u8(uint8_t *u8, uint16_t u16);

int find_len(uint8_t *kytu);


#endif // EXECUTEUINTX_T_H
