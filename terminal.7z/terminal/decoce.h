
#ifndef DECODE_H
#define DECODE_H


#include "stdio.h"
#include "string.h"
#include "cstdint"
#include "stdlib.h"

#include "executeuintx_t.h"
#include "basicstruct.h"
#include"encode.h"


//****************************************************************
//
// this fucntion use to decode input string to data field of CAN_Frame
//			change "0xFF" byte to 0x00
//	param: u8: input string
//			result: output array, this is data filed of CAN_Frame
//
//****************************************************************
void decode_u8(uint8_t *result, uint8_t *u8);

//****************************************************************
//
// this fucntion use to get ID field of CAN_Frame from output string
//	param: u8: input string
//			ID is ID field of CAN_frame
//
//****************************************************************
void getCANID(uint32_t *ID, uint8_t *u8);

//****************************************************************
//
// this fucntion use to get lenght field of CAN_Frame from output string
//	param: u8: input string
//			lenght is lenght field of CAN_frame
//
//****************************************************************
void getCANLenght(uint8_t *lenght, uint8_t *u8);


//****************************************************************
//
// this fucntion use to get data field of CAN_Frame from output string
//	param: u8: input string
//			data is lenght field of CAN_frame
//
//****************************************************************
void getCANData(uint8_t *data, uint8_t *u8);


//***********************************************************************
//
//	this function usr to convert string to CAN_Frame
//
//	u8 : input string
//	CANObject: is CANFrame, which we try to get value from string
//***********************************************************************

void u8_CANFrame(CAN_Frame *CANObject,uint8_t *u8);


#endif // !DECODE_H

//****************************************************************
//
// this fucntion use to get sourceID field of USB_Frame from output string
//	param: u8: input string
//			sourceID is sourceID field of USB_frame
//
//****************************************************************
void getSourceID(uint8_t *sourceID, uint8_t *u8);

//****************************************************************
//
// this fucntion use to get sourceType field of USB_Frame from output string
//	param: u8: input string
//			sourceType is sourceType field of USB_frame
//
//****************************************************************
void getSourceType(uint8_t *sourceType, uint8_t *u8);

//****************************************************************
//
// this fucntion use to get destID field of USB_Frame from output string
//	param: u8: input string
//			destID is destID field of USB_frame
//
//****************************************************************
void getDestID(uint8_t *destID, uint8_t *u8);

//****************************************************************
//
// this fucntion use to get destType field of USB_Frame from output string
//	param: u8: input string
//			destType is destType field of USB_frame
//
//****************************************************************
void getDestType(uint8_t *destType, uint8_t *u8);

//****************************************************************
//
// this fucntion use to get lenght field of USB_Frame from output string
//	param: u8: input string
//			lenght is lenght field of USB_frame
//
//****************************************************************
void getLenght(uint8_t *lenght, uint8_t *u8);

//****************************************************************
//
// this fucntion use to get commandID field of USB_Frame from output string
//	param: u8: input string
//			commandID is commandID field of USB_frame
//
//****************************************************************
void getCommandID(uint16_t *commandID, uint8_t *u8);

//***********************************************************************
//
//	this function usr to convert string to USB_Frame_forSimulator
//
//	u8 : input string
//	CANObject: is USB_Frame_forSimulator, which we try to get value from string
//***********************************************************************

void u8_USB_Frame_forSimulator(USB_Frame_forSimulator *USBObject, uint8_t *u8);

//****************************************************************
//
// this fucntion use to get lenght status of USB_Frame_forCheckAlive from output string
//	param: u8: input string
//			status is status field of USB_frame
//
//****************************************************************
void getStatus(uint8_t *status, uint8_t *u8);

//***********************************************************************
//
//	this function usr to convert string to USB_Frame_forCheckAlive
//
//	u8 : input string
//	CANObject: is USB_Frame_forCheckAlive, which we try to get value from string
//***********************************************************************

void u8_USB_Frame_forCheckAlive(USB_Frame_forCheckAlive *USBObject, uint8_t *u8);

//****************************************************************
//
// this fucntion use to get baundRate of USB_Frame_forConfig from output string
//	param: u8: input string
//			baundRate is baundRate field of USB_Frame_forConfig
//
//****************************************************************
void getbaundRate(uint8_t *baundRate, uint8_t *u8);

//****************************************************************
//
// this fucntion use to get BTR of USB_Frame_forConfig from output string
//	param: u8: input string
//			BTR is BTR field of USB_Frame_forConfig
//
//****************************************************************
void getBTR(uint8_t *BTR, uint8_t *u8);

//****************************************************************
//
// this fucntion use to get filter of USB_Frame_forConfig from output string
//	param: u8: input string
//			filter is filter field of USB_Frame_forConfig
//
//****************************************************************
void getFilter(uint32_t *filter, uint8_t *u8);


//***********************************************************************
//
//	this function use to convert string to USB_Frame_forConfig
//
//	u8 : input string
//	CANObject: is USB_Frame_forConfig, which we try to get value from string
//***********************************************************************

void u8_USB_Frame_forConfig(USB_Frame_forConfig *USBObject, uint8_t *u8);

//*************************************************************************************
//
//	DESCRIPTION
//	decode string to USB_Frame
//	param:
//		string : input data, that is output of encode()
//		type : 0 is FAILED
//			   1 is checkalive frame
//			   2 is config frame
//	return:
//		NULL: dynamic memory allocation
//		orthers: success add return output struct
//
//
//*************************************************************************************

ReturnStruct decode(uint8_t *string, int *type);

//#endif // DECODE_H
