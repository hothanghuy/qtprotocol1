#ifndef ENCODE_H
#define ENCODE_H


#include "stdio.h"
#include "string.h"
#include "cstdint"
#include "stdlib.h"
#include "executeuintx_t.h"
#include "basicstruct.h"

#include <inttypes.h>

//****************************************************************
//
//   create empty string
//
//****************************************************************

void creatString(uint8_t *u8);

//****************************************************************
//
// this fucntion use to add data field of CAN_Frame to output string
//	param: u8: output string
//			data[8] data field of CAN_frame
//
//****************************************************************
void addCANData(uint8_t *u8, uint8_t *data);

//****************************************************************
//
// this fucntion use to encode data field of CAN_Frame to output string
//			change "NULL" byte to 0xFF
//	param: u8: input array, this is data filed of CAN_Frame
//			result: output string, have syntax is "xxxxxxx}"
//
//****************************************************************
void encode_u8(uint8_t *result, uint8_t u8[8]);

//****************************************************************
//
// this fucntion use to add lenght field of CAN_Frame to output string
//	param: u8: output string
//			lenght data field of CAN_frame
//
//****************************************************************
void addCANLenght(uint8_t *u8, uint8_t lenght);

//****************************************************************
//
// this fucntion use to add ID field of CAN_Frame to output string
//	param: u8: output string
//			ID data field of CAN_frame
//
//****************************************************************
void addCANID(uint8_t *u8, uint32_t ID);

//***********************************************************************
//
//	this function use to convert  CAN_Frame to string
//
//	u8 : output string
//	CANObject: is CANFrame, which we try to convert to string
//***********************************************************************

void CANFrame_u8(uint8_t *u8, CAN_Frame CANObject);


//**************************************************************************************
//	DESCRIPTION
//	add sourceID field to string
//  param: string is output string
//			sourceID : sourceID field of USB_Frame_forSimulator
//
//***************************************************************************************

void addSourceID(uint8_t *u8, uint8_t sourceID);

//**************************************************************************************
//	DESCRIPTION
//	add destID field to string
//  param: string is output string
//			destID : destID field of USB_Frame_forSimulator
//
//***************************************************************************************

void addDestID(uint8_t *u8, uint8_t destID);

//**************************************************************************************
//	DESCRIPTION
//	add sourceType field to string
//  param: string is output string
//			sourceType : sourceType field of USB_Frame_forSimulator
//
//***************************************************************************************

void addSourceType(uint8_t *u8, uint8_t sourceType);

//**************************************************************************************
//	DESCRIPTION
//	add destType field to string
//  param: string is output string
//			destType : destType field of USB_Frame_forSimulator
//
//***************************************************************************************

void addDestType(uint8_t *u8, uint8_t destType);

//**************************************************************************************
//	DESCRIPTION
//	add lenght field to string
//  param: string is output string
//			lenght : lenght field of USB_Frame_forSimulator
//
//***************************************************************************************

void addLenght(uint8_t *u8, uint8_t lenght);

//**************************************************************************************
//	DESCRIPTION
//	add commandID field to string
//  param: string is output string
//			commandID : commandID field of USB_Frame_forSimulator
//
//***************************************************************************************

void addCommandID(uint8_t *u8, uint16_t commandID);

//***************************************************************************************
//
//	this function use to convert  USB_Frame_forSimulator to string
//
//	u8 : output string
//	USB_Object: is USB_Frame_forSimulator, which we try to convert to string
//
//****************************************************************************************

void USB_Frame_forSimulator_u8(uint8_t *u8, USB_Frame_forSimulator USB_Object);



//**************************************************************************************
//	DESCRIPTION
//	add status field of USB_forCheckAlive  to string
//  param: string is output string
//			status : status field of USB_forCheckAlive
//
//***************************************************************************************

void addStatus(uint8_t *u8, uint8_t status);

//***************************************************************************************
//
//	this function use to convert  USB_Frame_forCheckAlive to string
//
//	u8 : output string
//	USB_Object: is USB_Frame_forCheckAlive, which we try to convert to string
//
//****************************************************************************************

void USB_Frame_forCheckAlive_u8(uint8_t *u8, USB_Frame_forCheckAlive USB_Object);


//**************************************************************************************
//	DESCRIPTION
//	add baundRate field of USB_forConfig  to string
//  param: string is output string
//			baundRate : baundRate field of USB_forConfig
//
//***************************************************************************************

void addBaundRate(uint8_t *u8, uint8_t baundRate);

//**************************************************************************************
//	DESCRIPTION
//	add BTR field of USB_forConfig  to string
//  param: string is output string
//			BTR : BTR field of USB_forConfig
//
//***************************************************************************************

void addBTR(uint8_t *u8, uint8_t BTR);

//**************************************************************************************
//	DESCRIPTION
//	add filter field of USB_forConfig  to string
//  param: string is output string
//			BTR : BTR field of USB_forConfig
//
//***************************************************************************************

void addFilter(uint8_t *u8, uint32_t filter);

//***************************************************************************************
//
//	this function use to convert  USB_Frame_forConfig to string
//
//	u8 : output string
//	USB_Object: is USB_Frame_forConfig, which we try to convert to string
//
//****************************************************************************************

void USB_Frame_forConfig_u8(uint8_t *u8, USB_Frame_forConfig USB_Object);

//*************************************************************************************
//
//	DESCRIPTION
//	encode USB_Frame to string
//	param:
//		USB_Object : struct of USB_Frame
//	return:
//		NULL: dynamic memory allocation
//		orthers: success add return output string
//
//
//*************************************************************************************
void encode(USB_Frame_forCheckAlive USB_Object, uint8_t * u8);
void encode(USB_Frame_forSimulator USB_Object, uint8_t * u8);
void encode(USB_Frame_forConfig USB_Object, uint8_t * u8);


#endif // ENCODE_H
