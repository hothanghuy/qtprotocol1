
#include "decoce.h"

//****************************************************************
//
// this fucntion use to decode input string to data field of CAN_Frame
//			change "0xFF" byte to 0x00
//	param: u8: input string
//			result: output array, this is data filed of CAN_Frame
//
//****************************************************************
void decode_u8(uint8_t *result, uint8_t *u8)
{
        for (int i = 0; i <= 7; i++)
        {
                if (u8[i] != 0xFF)
                {
                        result[i] = u8[i];
                }
                else
                {
                        result[i] = 0x00;
                }
        }
};

//****************************************************************
//
// this fucntion use to get ID field of CAN_Frame from output string
//	param: u8: input string
//			ID data field of CAN_frame
//
//****************************************************************
void getCANID(uint32_t *ID, uint8_t *u8)
{
        uint8_t *u8ID = (uint8_t*)malloc(4);
        int i = 0, j = 0;
        // find out begin's of ID; "ID:"
        while (!(u8[i] == 0x7D))
        {
                if (u8[i] != (uint8_t)'I')
                {
                        i++;
                }
                else
                {
                        if (u8[i + 1] != (uint8_t)'D')
                        {
                                i++;
                        }
                        else
                        {
                                i += 3;
                                break;
                        }
                }
        }

        while (u8[i] != 0x2C)
        {
                if (j>3)
                {
                        break;
                }
                u8ID[j] = u8[i];
                i++;
                j++;
        }
        u8_u32(ID,u8ID);
        free(u8ID);
};

//****************************************************************
//
// this fucntion use to get lenght field of CAN_Frame from output string
//	param: u8: input string
//			lenght is lenght field of CAN_frame
//
//****************************************************************
void getCANLenght(uint8_t *lenght, uint8_t *u8)
{
        int i = 0;
        while (!(u8[i] == 0x7D))
        {
                if (u8[i] != (uint8_t)'C')
                {
                        i++;
                }
                else
                {
                        if (u8[i + 1] != (uint8_t)'l')
                        {
                                i++;
                        }
                        else
                                if (u8[i + 2] != (uint8_t)'e')
                                {
                                        i++;
                                }
                                else
                                {
                                        i += 5;
                                        break;
                                }

                }
        }
        *lenght = u8[i];
};

//****************************************************************
//
// this fucntion use to get data field of CAN_Frame from output string
//	param: u8 is  input string
//			data is lenght field of CAN_frame
//
//****************************************************************
void getCANData(uint8_t *data, uint8_t *u8)
{
        int i = 0, j = 0;
        // find out begin's of data; "data:"
        while (!(u8[i] == 0x7D))
        {
                if (u8[i] != (uint8_t)'d')
                {
                        i++;
                }
                else
                {
                        if (u8[i + 1] != (uint8_t)'a')
                        {
                                i++;
                        }
                        else
                                if (u8[i + 2] != (uint8_t)'t')
                                {
                                        i++;
                                }
                                else
                                {
                                        i += 5;
                                        break;
                                }

                }
        }
        // after "data:" is value of data
        // finish character is ','
        uint8_t *datab = (uint8_t*)malloc(8);
        while (u8[i] != 0x7D)
        {
                if (j>7)
                {
                        break;
                }
                datab[j] = u8[i];
                j++;
                i++;
        }
        decode_u8(data,datab);
        free(datab);
};

//***********************************************************************
//
//	this function usr to convert string to CAN_Frame
//
//	u8 : input string
//	CANObject: is CANFrame, which we try to get value from string
//***********************************************************************

void u8_CANFrame(CAN_Frame *CANObject, uint8_t *u8)
{
        uint32_t *ID = (uint32_t*)malloc(4);
        uint8_t *lenght = (uint8_t*)malloc(1);
        uint8_t data[8];
        getCANID(ID,u8);
        getCANLenght(lenght,u8);
        getCANData(data,u8);
        CANObject->ID = *ID;
        CANObject->lenght = *lenght;
        for (int i = 0; i <= 7; i++)
        {
                CANObject->data[i] = data[i];
        }
        free(ID);
        free(lenght);
}

//****************************************************************
//
// this fucntion use to get sourceID field of USB_Frame from output string
//	param: u8: input string
//			sourceID is sourceID field of USB_frame
//
//****************************************************************
void getSourceID(uint8_t *sourceID, uint8_t *u8)
{
        int i = 0;
        while (!(u8[i] == 0x7D))
        {
                if (u8[i] != (uint8_t)'s')
                {
                        i++;
                }
                else
                {
                        if (u8[i + 1] != (uint8_t)'i')
                        {
                                i++;
                        }
                        else
                                if (u8[i + 2] != (uint8_t)'D')
                                {
                                        i++;
                                }
                                else
                                {
                                        i += 4;
                                        break;
                                }

                }
        }
        *sourceID = u8[i];
}


//****************************************************************
//
// this fucntion use to get sourceType field of USB_Frame from output string
//	param: u8: input string
//			sourceType is sourceType field of USB_frame
//
//****************************************************************
void getSourceType(uint8_t *sourceType, uint8_t *u8)
{
        int i = 0;
        while (!(u8[i] == 0x7D))
        {
                if (u8[i] != (uint8_t)'s')
                {
                        i++;
                }
                else
                {
                        if (u8[i + 1] != (uint8_t)'T')
                        {
                                i++;
                        }
                        else
                                if (u8[i + 2] != (uint8_t)'y')
                                {
                                        i++;
                                }
                                else
                                {
                                        i += 6;
                                        break;
                                }

                }
        }
        *sourceType = u8[i];
}

//****************************************************************
//
// this fucntion use to get destID field of USB_Frame from output string
//	param: u8: input string
//			destID is destID field of USB_frame
//
//****************************************************************
void getDestID(uint8_t *destID, uint8_t *u8)
{
        int i = 0;
        while (!(u8[i] == 0x7D))
        {
                if (u8[i] != (uint8_t)'d')
                {
                        i++;
                }
                else
                {
                        if (u8[i + 1] != (uint8_t)'i')
                        {
                                i++;
                        }
                        else
                                if (u8[i + 2] != (uint8_t)'D')
                                {
                                        i++;
                                }
                                else
                                {
                                        i += 4;
                                        break;
                                }

                }
        }
        *destID = u8[i];
}


//****************************************************************
//
// this fucntion use to get destType field of USB_Frame from output string
//	param: u8: input string
//			destType is destType field of USB_frame
//
//****************************************************************
void getDestType(uint8_t *destType, uint8_t *u8)
{

        int i = 0;
        while (!(u8[i] == 0x7D))
        {
                if (u8[i] != (uint8_t)'d')
                {
                        i++;
                }
                else
                {
                        if (u8[i + 1] != (uint8_t)'T')
                        {
                                i++;
                        }
                        else
                                if (u8[i + 2] != (uint8_t)'y')
                                {
                                        i++;
                                }
                                else
                                {
                                        i += 6;
                                        break;
                                }

                }
        }
        *destType = u8[i];
}

//****************************************************************
//
// this fucntion use to get lenght field of USB_Frame from output string
//	param: u8: input string
//			lenght is lenght field of USB_frame
//
//****************************************************************
void getLenght(uint8_t *lenght, uint8_t *u8)
{
        int i = 0;
        while (!(u8[i] == 0x7D))
        {
                if (u8[i] != (uint8_t)'l')
                {
                        i++;
                }
                else
                {
                        if (u8[i + 1] != (uint8_t)'U')
                        {
                                i++;
                        }
                        else
                                if (u8[i + 2] != (uint8_t)'S')
                                {
                                        i++;
                                }
                                else
                                {
                                        i += 5;
                                        break;
                                }

                }
        }
        *lenght = u8[i];
}

//****************************************************************
//
// this fucntion use to get commandID field of USB_Frame from output string
//	param: u8: input string
//			commandID is commandID field of USB_frame
//
//****************************************************************
void getCommandID(uint16_t *commandID, uint8_t *u8)
{
        uint8_t cmI[2];
        int i = 0;
        while (!(u8[i] == 0x7D))
        {
                if (u8[i] != (uint8_t)'c')
                {
                        i++;
                }
                else
                {
                        if (u8[i + 1] != (uint8_t)'m')
                        {
                                i++;
                        }
                        else
                                if (u8[i + 2] != (uint8_t)'i')
                                {
                                        i++;
                                }
                                else
                                {
                                        i += 5;
                                        break;
                                }

                }
        }
        cmI[0] = u8[i];
        cmI[1] = u8[i + 1];
        u8_u16(commandID, cmI);
}


//***********************************************************************
//
//	this function usr to convert string to USB_Frame_forSimulator
//
//	u8 : input string
//	CANObject: is USB_Frame_forSimulator, which we try to get value from string
//***********************************************************************

void u8_USB_Frame_forSimulator(USB_Frame_forSimulator *USBObject, uint8_t *u8)
{
        uint8_t *sourceID = (uint8_t*)malloc(1);
        uint8_t *destID = (uint8_t*)malloc(1);
        uint8_t *sourceType = (uint8_t*)malloc(1);
        uint8_t *destType = (uint8_t*)malloc(1);
        uint8_t *lenght = (uint8_t*)malloc(1);
        uint16_t *cmID = (uint16_t*)malloc(2);
        CAN_Frame *can = (CAN_Frame*)malloc(sizeof(CAN_Frame));
        getSourceID(sourceID,u8);
        getSourceType(sourceType,u8);
        getDestID(destID, u8);
        getDestType(destType, u8);
        getLenght(lenght, u8);
        getCommandID(cmID, u8);
        u8_CANFrame(can,u8);
        USBObject->sourceID = *sourceID;
        USBObject->sourceType = *sourceType;
        USBObject->destID = *destID;
        USBObject->destType = *destType;
        USBObject->commandID = *cmID;
        USBObject->lenght = *lenght;
        USBObject->CAN_Oject = *can;
        free(sourceID);
        free(sourceType);
        free(destID);
        free(destType);
        free(cmID);
        free(lenght);
        free(can);
}

//****************************************************************
//
// this fucntion use to get lenght status of USB_Frame_forCheckAlive from output string
//	param: u8: input string
//			status is status field of USB_frame
//
//****************************************************************
void getStatus(uint8_t *status, uint8_t *u8)
{
        int i = 0;
        while (!(u8[i] == 0x7D))
        {
                if (u8[i] != (uint8_t)'s')
                {
                        i++;
                }
                else
                {
                        if (u8[i + 1] != (uint8_t)'t')
                        {
                                i++;
                        }
                        else
                                if (u8[i + 2] != (uint8_t)'s')
                                {
                                        i++;
                                }
                                else
                                {
                                        i += 4;
                                        break;
                                }

                }
        }
        *status = u8[i];
}

//***********************************************************************
//
//	this function usr to convert string to USB_Frame_forCheckAlive
//
//	u8 : input string
//	CANObject: is USB_Frame_forCheckAlive, which we try to get value from string
//***********************************************************************

void u8_USB_Frame_forCheckAlive(USB_Frame_forCheckAlive *USBObject, uint8_t *u8)
{
        uint8_t *sourceID = (uint8_t*)malloc(1);
        uint8_t *destID = (uint8_t*)malloc(1);
        uint8_t *sourceType = (uint8_t*)malloc(1);
        uint8_t *destType = (uint8_t*)malloc(1);
        uint8_t *lenght = (uint8_t*)malloc(1);
        uint16_t *cmID = (uint16_t*)malloc(2);
        uint8_t *sts = (uint8_t*)malloc(1);
        getSourceID(sourceID, u8);
        getSourceType(sourceType, u8);
        getDestID(destID, u8);
        getDestType(destType, u8);
        getLenght(lenght, u8);
        getCommandID(cmID, u8);
        getStatus(sts,u8);
        USBObject->sourceID = *sourceID;
        USBObject->sourceType = *sourceType;
        USBObject->destID = *destID;
        USBObject->destType = *destType;
        USBObject->commandID = *cmID;
        USBObject->lenght = *lenght;
        USBObject->CheckALive_Frame.status = *sts;
        free(sourceID);
        free(sourceType);
        free(destID);
        free(destType);
        free(cmID);
        free(lenght);
        free(sts);
}

//****************************************************************
//
// this fucntion use to get baundRate of USB_Frame_forConfig from output string
//	param: u8: input string
//			baundRate is baundRate field of USB_Frame_forConfig
//
//****************************************************************
void getbaundRate(uint8_t *baundRate, uint8_t *u8)
{
        int i = 0;
        while (!(u8[i] == 0x7D))
        {
                if (u8[i] != (uint8_t)'b')
                {
                        i++;
                }
                else
                {
                        if (u8[i + 1] != (uint8_t)'a')
                        {
                                i++;
                        }
                        else
                                if (u8[i + 2] != (uint8_t)'R')
                                {
                                        i++;
                                }
                                else
                                {
                                        i += 4;
                                        break;
                                }

                }
        }
        *baundRate = u8[i];
}

//****************************************************************
//
// this fucntion use to get BTR of USB_Frame_forConfig from output string
//	param: u8: input string
//			BTR is BTR field of USB_Frame_forConfig
//
//****************************************************************
void getBTR(uint8_t *BTR, uint8_t *u8)
{
        int i = 0;
        while (!(u8[i] == 0x7D))
        {
                if (u8[i] != (uint8_t)'B')
                {
                        i++;
                }
                else
                {
                        if (u8[i + 1] != (uint8_t)'T')
                        {
                                i++;
                        }
                        else
                                if (u8[i + 2] != (uint8_t)'R')
                                {
                                        i++;
                                }
                                else
                                {
                                        i += 4;
                                        break;
                                }

                }
        }
        *BTR = u8[i];
}

//****************************************************************
//
// this fucntion use to get filter of USB_Frame_forConfig from output string
//	param: u8: input string
//			filter is filter field of USB_Frame_forConfig
//
//****************************************************************
void getFilter(uint32_t *filter, uint8_t *u8)
{
        int i = 0, j =0;
        uint8_t *u8Filter = (uint8_t*)malloc(4);
        while (!(u8[i] == 0x7D))
        {
                if (u8[i] != (uint8_t)'f')
                {
                        i++;
                }
                else
                {
                        if (u8[i + 1] != (uint8_t)'i')
                        {
                                i++;
                        }
                        else
                                if (u8[i + 2] != (uint8_t)'l')
                                {
                                        i++;
                                }
                                else
                                {
                                        i += 4;
                                        break;
                                }

                }
        }
        while (u8[i] != 0x2C)
        {
                if (j>3)
                {
                        break;
                }
                u8Filter[j] = u8[i];
                i++;
                j++;
        }
        u8_u32(filter, u8Filter);
}

//***********************************************************************
//
//	this function use to convert string to USB_Frame_forConfig
//
//	u8 : input string
//	CANObject: is USB_Frame_forConfig, which we try to get value from string
//***********************************************************************

void u8_USB_Frame_forConfig(USB_Frame_forConfig *USBObject, uint8_t *u8)
{
        uint8_t *sourceID = (uint8_t*)malloc(1);
        uint8_t *destID = (uint8_t*)malloc(1);
        uint8_t *sourceType = (uint8_t*)malloc(1);
        uint8_t *destType = (uint8_t*)malloc(1);
        uint8_t *lenght = (uint8_t*)malloc(1);
        uint16_t *cmID = (uint16_t*)malloc(2);
        uint8_t *baundRate = (uint8_t*)malloc(1);
        uint8_t *BTR = (uint8_t*)malloc(1);
        uint32_t *filter = (uint32_t*)malloc(4);
        getSourceID(sourceID, u8);
        getSourceType(sourceType, u8);
        getDestID(destID, u8);
        getDestType(destType, u8);
        getLenght(lenght, u8);
        getCommandID(cmID, u8);
        getbaundRate(baundRate,u8);
        getBTR(BTR,u8);
        getFilter(filter,u8);
        USBObject->sourceID = *sourceID;
        USBObject->sourceType = *sourceType;
        USBObject->destID = *destID;
        USBObject->destType = *destType;
        USBObject->commandID = *cmID;
        USBObject->lenght = *lenght;
        USBObject->Configuration_Frame.baudRates = *baundRate;
        USBObject->Configuration_Frame.BTR = *BTR;
        USBObject->Configuration_Frame.filter = *filter;
        free(sourceID);
        free(sourceType);
        free(destID);
        free(destType);
        free(cmID);
        free(lenght);
        free(baundRate);
        free(BTR);
        free(filter);
}

//*************************************************************************************
//
//	DESCRIPTION
//	decode string to USB_Frame
//	param:
//		string : input data, that is output of encode()
//		type : 0 is FAILED
//			   1 is checkalive frame
//			   2 is config frame
//	return:
//		NULL: dynamic memory allocation
//		orthers: success add return output struct
//
//
//*************************************************************************************

ReturnStruct decode(uint8_t *string, int *type)
{
        uint16_t u16;
        getCommandID(&u16,string);
        ReturnStruct result;
        if (u16 == 0x4E4E || u16 == 0x4E4F || u16 == 0x0022)
        {
                *type = CHECKALIVE;
                u8_USB_Frame_forCheckAlive(&(result.USBcheckAlive),string);
        }
        else
        {
                if (u16 >= 0x000D && u16 <= 0x0012)
                {
                        *type = CONFIG;
                        u8_USB_Frame_forConfig(&(result.USBconfig),string);
                }
                else
                {
                        if (u16 >= 0x0013 && u16 <= 0x0021)
                        {
                                *type = SIMULATOR;
                                u8_USB_Frame_forSimulator(&(result.USBsimulator),string);
                        }
                        else
                        {
                                *type = FAILED;
                                u8_USB_Frame_forSimulator(&(result.USBsimulator), string);
                        }
                }
        }
        return result;
}
