#include "encode.h"
#include <QtCore>

//****************************************************************
//
//   create empty string
//
//****************************************************************

void creatString(uint8_t *u8)
{
        u8[0] = (uint8_t)'{';
        u8[1] = (uint8_t)'}';
};

//****************************************************************
//
// this fucntion usto add data field of CAN_Frame to output string
//	param: u8: output string
//			data[8] data field of CAN_frame
//
//****************************************************************

void addCANData(uint8_t *u8, uint8_t *data)
{
        uint8_t dataString[] = ",data:}";
        memcpy(u8+find_len(u8)-1,dataString,find_len(dataString));
        memcpy(u8+find_len(u8)-1, data,find_len(data));
};

//****************************************************************
//
// this fucntion use to encode data field of CAN_Frame to output string
//			change "NULL" byte to 0xFF
//	param: u8: input array, this is data filed of CAN_Frame
//			result: output string, have syntax is "xxxxxxx}"
//
//****************************************************************
void encode_u8(uint8_t *result, uint8_t u8[8])
{
        for (int i = 0; i <= 7; i++)
        {
                if (u8[i] != 0x00)
                {
                        result[i] = u8[i];
                }
                else
                {
                        result[i] = 0xFF;
                }
        }
        result[8] = 0x7D;

};

//****************************************************************
//
// this fucntion usto add lenght field of CAN_Frame to output string
//	param: u8: output string
//			lenght data field of CAN_frame
//
//****************************************************************

void addCANLenght(uint8_t *u8, uint8_t lenght)
{
        uint8_t lenghtString[] = ",Clen:}";
        uint8_t len[2];
        len[0] = lenght;
        len[1] = (uint8_t)'}';
        memcpy(u8+find_len(u8)-1, lenghtString, find_len(lenghtString));
        memcpy(u8 + find_len(u8) - 1, len , find_len(len));
};

//****************************************************************
//
// this fucntion usto add ID field of CAN_Frame to output string
//	param: u8: output string
//			ID data field of CAN_frame
//
//****************************************************************
void addCANID(uint8_t *u8, uint32_t ID)
{
        uint8_t IDString[] = ",ID:}";
        uint8_t *u8ID = (uint8_t*)malloc(6);
        u32_u8(u8ID,ID);
        memcpy(u8+find_len(u8)-1,IDString,find_len(IDString));
        memcpy(u8 + find_len(u8) - 1,u8ID, find_len(u8ID));
        free(u8ID);
};


//***********************************************************************
//
//	this function usr to convert  CAN_Frame to string
//
//	u8 : output string
//	CANObject: is CANFrame, which we try to convert to string
//***********************************************************************

void CANFrame_u8(uint8_t *u8, CAN_Frame CANObject)
{
        creatString(u8);
        uint8_t *data = (uint8_t*)malloc(9);
        encode_u8(data,CANObject.data);
        addCANID(u8,CANObject.ID);
        addCANLenght(u8,CANObject.lenght);
        addCANData(u8,data);
        free(data);
};

//**************************************************************************************
//	DESCRIPTION
//	add sourceID field to string
//  param: string is output string
//			sourceID : sourceID field of USB_Frame_forSimulator
//
//***************************************************************************************

void addSourceID(uint8_t *u8, uint8_t sourceID)
{
        uint8_t sourceIDString[] = "siD:}";
        uint8_t SID[2];
        SID[0] = sourceID;
        SID[1] = (uint8_t)'}';
        memcpy(u8 + find_len(u8) - 1, sourceIDString, find_len(sourceIDString));
        memcpy(u8 + find_len(u8) - 1, SID, find_len(SID));
}

//**************************************************************************************
//	DESCRIPTION
//	add sourceType field to string
//  param: string is output string
//			sourceType : sourceType field of USB_Frame_forSimulator
//
//***************************************************************************************

void addSourceType(uint8_t *u8, uint8_t sourceType)
{
        uint8_t sourceTypeString[] = ",sType:}";
        uint8_t SType[2];
        SType[0] = sourceType;
        SType[1] = (uint8_t)'}';
        memcpy(u8 + find_len(u8) - 1, sourceTypeString, find_len(sourceTypeString));
        memcpy(u8 + find_len(u8) - 1, SType, find_len(SType));
}

//**************************************************************************************
//	DESCRIPTION
//	add destID field to string
//  param: string is output string
//			destID : destID field of USB_Frame_forSimulator
//
//***************************************************************************************

void addDestID(uint8_t *u8, uint8_t destID)
{
        uint8_t destIDString[] = ",diD:}";
        uint8_t dest[2];
        dest[0] = destID;
        dest[1] = (uint8_t)'}';
        memcpy(u8 + find_len(u8) - 1, destIDString, find_len(destIDString));
        memcpy(u8 + find_len(u8) - 1, dest, find_len(dest));
}


//**************************************************************************************
//	DESCRIPTION
//	add destType field to string
//  param: string is output string
//			destType : destType field of USB_Frame_forSimulator
//
//***************************************************************************************

void addDestType(uint8_t *u8, uint8_t destType)
{
        uint8_t destTypeString[] = ",dType:}";
        uint8_t dest[2];
        dest[0] = destType;
        dest[1] = (uint8_t)'}';
        memcpy(u8 + find_len(u8) - 1, destTypeString, find_len(destTypeString));
        memcpy(u8 + find_len(u8) - 1, dest, find_len(dest));
}

//**************************************************************************************
//	DESCRIPTION
//	add lenght field to string
//  param: string is output string
//			lenght : lenght field of USB_Frame_forSimulator
//
//***************************************************************************************

void addLenght(uint8_t *u8, uint8_t lenght)
{
        uint8_t lenString[] = ",lUSB:}";
        uint8_t len[2];
        len[0] = lenght;
        len[1] = (uint8_t)'}';
        memcpy(u8 + find_len(u8) - 1, lenString, find_len(lenString));
        memcpy(u8 + find_len(u8) - 1, len, find_len(len));
}

//**************************************************************************************
//	DESCRIPTION
//	add commandID field to string
//  param: string is output string
//			commandID : commandID field of USB_Frame_forSimulator
//
//***************************************************************************************

void addCommandID(uint8_t *u8, uint16_t commandID)
{
        uint8_t cmIDString[] = "cmiD:}";
        uint8_t *cmID = (uint8_t*)malloc(3);
        u16_u8(cmID,commandID);
        memcpy(u8 + find_len(u8) - 1, cmIDString, find_len(cmIDString));
        memcpy(u8 + find_len(u8) - 1, cmID, find_len(cmID));
        free(cmID);
}

//***************************************************************************************
//
//	this function use to convert  USB_Frame_forSimulator to string
//
//	u8 : output string
//	USB_Object: is USB_Frame_forSimulator, which we try to convert to string
//
//****************************************************************************************

void USB_Frame_forSimulator_u8(uint8_t *u8, USB_Frame_forSimulator USB_Object)
{
        uint8_t *canString = (uint8_t *)malloc(sizeof(CAN_Frame)+30);
        CANFrame_u8(canString, USB_Object.CAN_Oject);
        creatString(u8);
        addSourceID(u8, USB_Object.sourceID);
        addDestID(u8, USB_Object.destID);
        addSourceType(u8, USB_Object.sourceType);
        addDestType(u8, USB_Object.destType);
        addCommandID(u8, USB_Object.commandID);
        addLenght(u8, USB_Object.lenght);
        memcpy(u8 + find_len(u8) - 1, canString + 1, find_len(canString));
        free(canString);
}


//**************************************************************************************
//	DESCRIPTION
//	add status of USB_forCheckAlive field to string
//  param: string is output string
//			status : status field of USB_forCheckAlive
//
//***************************************************************************************

void addStatus(uint8_t *u8, uint8_t status)
{
        uint8_t statusString[] = "sts:}";
        uint8_t *sts = (uint8_t*)malloc(2);
        sts[0] = status;
        sts[1] = (uint8_t)'}';
        memcpy(u8+find_len(u8)-1,statusString, find_len(statusString));
        memcpy(u8+find_len(u8)-1, sts, 2);
        free(sts);
}
//***************************************************************************************
//
//	this function use to convert  USB_Frame_forCheckAlive to string
//
//	u8 : output string
//	USB_Object: is USB_Frame_forCheckAlive, which we try to convert to string
//
//****************************************************************************************

void USB_Frame_forCheckAlive_u8(uint8_t *u8, USB_Frame_forCheckAlive USB_Object)
{
        creatString(u8);
        addSourceID(u8, USB_Object.sourceID);
        addDestID(u8, USB_Object.destID);
        addSourceType(u8, USB_Object.sourceType);
        addDestType(u8, USB_Object.destType);
        addCommandID(u8, USB_Object.commandID);
        addLenght(u8, USB_Object.lenght);
        addStatus(u8,USB_Object.CheckALive_Frame.status);
}


//**************************************************************************************
//	DESCRIPTION
//	add baundRate field of USB_forConfig  to string
//  param: string is output string
//			baundRate : baundRate field of USB_forConfig
//
//***************************************************************************************

void addBaundRate(uint8_t *u8, uint8_t baundRate)
{
        uint8_t baundRateString[] = ",baR:}";
        uint8_t bauR[2];
        bauR[0] = baundRate;
        bauR[1] = (uint8_t)'}';
        memcpy(u8 + find_len(u8) - 1, baundRateString, find_len(baundRateString));
        memcpy(u8 + find_len(u8) - 1, bauR, find_len(bauR));
}

//**************************************************************************************
//	DESCRIPTION
//	add BTR field of USB_forConfig  to string
//  param: string is output string
//			BTR : BTR field of USB_forConfig
//
//***************************************************************************************

void addBTR(uint8_t *u8, uint8_t BTR)
{
        uint8_t BTRString[] = ",BTR:}";
        uint8_t BTRb[2];
        BTRb[0] = BTR;
        BTRb[1] = (uint8_t)'}';
        memcpy(u8 + find_len(u8) - 1, BTRString, find_len(BTRString));
        memcpy(u8 + find_len(u8) - 1, BTRb, find_len(BTRb));
}

//**************************************************************************************
//	DESCRIPTION
//	add filter field of USB_forConfig  to string
//  param: string is output string
//			BTR : BTR field of USB_forConfig
//
//***************************************************************************************

void addFilter(uint8_t *u8, uint32_t filter)
{
        uint8_t filterString[] = ",fil:}";
        uint8_t *u8filter = (uint8_t*)malloc(6);
        u32_u8(u8filter, filter);
        memcpy(u8 + find_len(u8) - 1, filterString, find_len(filterString));
        memcpy(u8 + find_len(u8) - 1, u8filter, find_len(u8filter));
        free(u8filter);
}

//***************************************************************************************
//
//	this function use to convert  USB_Frame_forConfig to string
//
//	u8 : output string
//	USB_Object: is USB_Frame_forConfig, which we try to convert to string
//
//****************************************************************************************

void USB_Frame_forConfig_u8(uint8_t *u8, USB_Frame_forConfig USB_Object)
{
        creatString(u8);
        addSourceID(u8, USB_Object.sourceID);
        addDestID(u8, USB_Object.destID);
        addSourceType(u8, USB_Object.sourceType);
        addDestType(u8, USB_Object.destType);
        addCommandID(u8, USB_Object.commandID);
        addLenght(u8, USB_Object.lenght);
        addBaundRate(u8,USB_Object.Configuration_Frame.baudRates);
        addBTR(u8,USB_Object.Configuration_Frame.BTR);
        addFilter(u8, USB_Object.Configuration_Frame.filter);
}
//*************************************************************************************
//
//	DESCRIPTION
//	encode USB_Frame to string
//	param:
//		USB_Object : struct of USB_Frame
//	return:
//		NULL: dynamic memory allocation
//		orthers: success add return output string
//
//
//*************************************************************************************
void encode(USB_Frame_forCheckAlive USB_Object, uint8_t * u8)
{
        USB_Frame_forCheckAlive_u8(u8, USB_Object);
}

void encode(USB_Frame_forSimulator USB_Object, uint8_t * u8)
{
        USB_Frame_forSimulator_u8(u8, USB_Object);
}
void encode(USB_Frame_forConfig USB_Object, uint8_t * u8)
{
        USB_Frame_forConfig_u8(u8, USB_Object);
}
