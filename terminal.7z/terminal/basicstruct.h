#ifndef BASICSTRUCT_H
#define BASICSTRUCT_H


#include "stdio.h"
#include "string.h"
#include "cstdint"
#include "stdlib.h"



//====================DEFAULT STRUCT OF USB ===================
typedef struct messageUSB_t
{
     uint8_t sourceID ;
     uint8_t destID ;
     uint8_t sourceType ;
     uint8_t destType ;
     uint16_t commandID ;
     uint8_t len ;
     uint8_t * dataUSB;
}messageUSB_t __attribute__( ( aligned(32) ) ) ;

//********************************************************************************
//
//	 type flag
//
//********************************************************************************

enum returnType
{
    FAILED,//0
    SIMULATOR,
    CHECKALIVE,
    CONFIG
};
//*********************************************************************************
//
// this is CAN_Frame
//
//**********************************************************************************

typedef struct CAN_Frame
{
    uint32_t ID;
    uint8_t lenght;
    uint8_t data[8];
} CAN_Frame;

typedef struct CheckALive_t
{
    uint8_t status; //status = 1: alive, status = 0: die
}CheckALive_t;

typedef struct Configuration_t
{
    uint8_t baudRates;      //BaudRates
    uint8_t BTR;            //Bus Timing Register
    uint32_t filter;        //filter mask ID (11 bit standard, 23 bits extend)
}Configuration_t;

//*************************************************************************************
//
// this is USB_Frame
//
//*************************************************************************************
typedef struct USB_Frame_forSimulator
{
    uint8_t sourceID;
    uint8_t destID;
    uint8_t sourceType;
    uint8_t destType;
    uint16_t commandID;
    uint8_t lenght;
    CAN_Frame CAN_Oject;
} USB_Frame_forSimulator;



typedef struct USB_Frame_forCheckAlive
{
    uint8_t sourceID;
    uint8_t destID;
    uint8_t sourceType;
    uint8_t destType;
    uint16_t commandID;
    uint8_t lenght;
    CheckALive_t CheckALive_Frame;
} USB_Frame_forCheckAlive;

typedef struct USB_Frame_forConfig
{
    uint8_t sourceID;
    uint8_t destID;
    uint8_t sourceType;
    uint8_t destType;
    uint16_t commandID;
    uint8_t lenght;
    Configuration_t Configuration_Frame;

} USB_Frame_forConfig;

//*****************************************************************************
//
//	typedata return after call decode();
//	base on flag "type" to choose struct
//
//*****************************************************************************

typedef union ReturnStruct
{
    USB_Frame_forSimulator USBsimulator;
    USB_Frame_forCheckAlive USBcheckAlive;
    USB_Frame_forConfig USBconfig;
} ReturnStruct;

//*****************************************************************************
//
//	thread_data return after call thread;
//
//*****************************************************************************
typedef struct str_thdata
{
    int fd;
    int timeout;
    int expected_variable;
    ReturnStruct usb_transmit;           // used to save struct wanted to transmit
    ReturnStruct usb_receiver;           // used to save struct received from board
    uint8_t * array_tempt_transmit;      // this array is used to save array after encode
    uint8_t * array_tempt_receiver;      // this array is used to save array after receiver from board
    int thread_probe;                    // 0: continue thread, 1 : stop thread
    int len;                             // len of data to transmit
    int result;
    int (*process)(ReturnStruct );
    int *type;
    int simulation_check;
}thread_data_t;



#endif // BASICSTRUCT_H
